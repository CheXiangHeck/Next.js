# Hackthletes-workshop-nextjs
Template for APU Hackthletes Next.js workshop

# Installation
APU Hackthletes handbook: https://images.lumacdn.com/editor-attachments/vj/6d2a795a-cd84-412f-bd1e-f36ffc4e2c62
1. node.js: https://nodejs.org/en/download
2. Package manager
3. Install yarn
4. Dependency install: yarn add @heroicons/react react-dom react-typewriter-effect react-type-animation framer-motion

